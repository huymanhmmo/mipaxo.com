@echo off
title Mipaxo - Profiles and Automation
echo =====================================================================
echo           MIPAXO - PROFILES AND AUTOMATION
echo =====================================================================
echo.

echo [1/2] Dang kiem tra trang thai he thong...
echo [2/2] Dang khoi chay Mipaxo Desktop (mipaxo.exe)...
if exist "%~dp0mipaxo.exe" (
    start "" "%~dp0mipaxo.exe"
) else if exist "%~dp0bin\mipaxo.exe" (
    start "" "%~dp0bin\mipaxo.exe"
) else (
    echo [ERROR] Khong tim thay mipaxo.exe! Vui long giai nen day du goi phan mem.
    exit /b 1
)

echo.
echo =====================================================================
echo [OK] DA KHOI DONG THANH CONG MIPAXO!
echo - Cua so Mipaxo Desktop dang hien thi.
echo - San sang su dung cac tinh nang quan ly profile va proxy.
echo =====================================================================
echo.
ping 127.0.0.1 -n 3 >nul
exit /b 0
