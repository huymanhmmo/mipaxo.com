@echo off
title Mipaxo - Profiles and Automation
echo =====================================================================
echo           MIPAXO - PROFILES AND AUTOMATION (DUAL-ENGINE)
echo =====================================================================
echo.
echo [1/2] Dang kiem tra va khoi dong Mipaxo Desktop...

set "EXE_PATH=%~dp0mipaxo.exe"
if not exist "%EXE_PATH%" set "EXE_PATH=%~dp0bin\mipaxo.exe"
if not exist "%EXE_PATH%" set "EXE_PATH=%~dp0projects\tool\target\release\mipaxo.exe"

if not exist "%EXE_PATH%" (
    echo [ERROR] Khong tim thay file mipaxo.exe!
    echo Vui long kiem tra lai thu muc hoac chay scripts\backtest_system.ps1 de bien dich.
    pause
    exit /b 1
)

start "" "%EXE_PATH%"

echo.
echo [2/2] Da gui lenh khoi chay thanh cong!
echo - Cua so ung dung Mipaxo dang hien thi tren man hinh.
echo - San sang su dung cac tinh nang quan ly profile, RPA va proxy.
echo =====================================================================
echo.
timeout /t 2 >nul
exit /b 0
